def includeme(config):
    config.add_route("initiate", "/initiate")
    config.add_route("download", "/download")
