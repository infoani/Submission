import datetime
from base64 import b64encode
from asyncworker.celery import app
from asyncworker.sort import SortConsecutive
from asyncworker.aws_s3 import S3


@app.task
def merge_s3_files():
    """Async task to download files from S3, merge them and upload the result.

    The lines in the merged file should be ordered.
    """
    
    # date_diff = end_dt - start_dt
    # _s3_client = S3()
    # _sort = SortConsecutive()

    # final_file_content = []
    # for i in range(date_diff.days + 1):
    #     cur_dt = start_dt + datetime.timedelta(days=i) 
    #     files = _s3_client.get_files(prefix=cur_dt.strftime("%Y-%m-%d"))
    #     for file in files:
    #         _sort.append(file)
    #     else:
    #         sorted_files = _sort.sorted_list()
    #         if sorted_files:
    #             temp_content = ''.join(map(lambda c: c.read(), sorted_files))
    #             final_file_content.append(temp_content)
    # else:
    #     return b64encode(''.join(final_file_content))

    return "something_there"




