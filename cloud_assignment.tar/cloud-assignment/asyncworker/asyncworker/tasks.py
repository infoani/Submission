from asyncworker.celery import app
from asyncworker.sort import SortConsecutive
from asyncworker.aws_s3 import S3


@app.task
def merge_s3_files(start_dt, end_dt):
    """Async task to download files from S3, merge them and upload the result.

    The lines in the merged file should be ordered.
    """
    pass
