import os
import datetime
import logging
import asyncworker.config as settings
from base64 import b64encode
from asyncworker.celery import app
from asyncworker.sort import SortConsecutive
from asyncworker.aws_s3 import S3

log_path = settings.LOG_PATH
logger = logging.getLogger(__name__)

@app.task
def merge_s3_files(start_dt_str, end_dt_str):
    """Async task to download files from S3, merge them and upload the result.

    The lines in the merged file should be ordered.
    """
    
    start_dt = datetime.datetime.strptime(start_dt_str, "%Y-%m-%d")
    end_dt = datetime.datetime.strptime(end_dt_str, "%Y-%m-%d")

    date_diff = end_dt - start_dt
    _s3_client = S3()
    _sort = SortConsecutive()

    file_name = start_dt_str + "/" + end_dt_str + ".log"
    new_file_path = os.path.join(log_path, file_name)
    with open(new_file_path, 'wb') as fh:
        # for i in range(date_diff.days + 1):
        #     cur_dt = start_dt + datetime.timedelta(days=i) 
        #     files = _s3_client.get_files(bucket="logs", prefix=cur_dt.strftime("%Y-%m-%d"))
        #     for file in files:
        #         index = None # to be implemented
        #         _sort.add(index, file)
        #     else:
        #         sorted_files = _sort.sorted_list()
        #         if sorted_files:
        #             temp_content = ''.join(map(lambda c: c.read(), sorted_files)) + "\n" # adding new_line between file parts
        #             fh.write(temp_content)
        # else:
        #     logger.info(f"Merge request completed. File {file_name} created.")

        fh.write("testing")

    return new_file_path