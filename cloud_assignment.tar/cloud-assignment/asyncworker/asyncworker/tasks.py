import os
import re
import datetime
import logging
import asyncworker.config as settings
from base64 import b64encode
from asyncworker.celery import app
from asyncworker.sort import SortConsecutive
from asyncworker.aws_s3 import S3

log_path = settings.LOG_PATH
logger = logging.getLogger(__name__)

@app.task
def merge_s3_files(start_dt_str, end_dt_str):
    """Async task to download files from S3, merge them and upload the result.

    The lines in the merged file should be ordered.
    """
    
    start_dt = datetime.datetime.strptime(start_dt_str, "%Y-%m-%d")
    end_dt = datetime.datetime.strptime(end_dt_str, "%Y-%m-%d")

    date_diff = end_dt - start_dt
    _s3_client = S3()
    _sort = SortConsecutive()

    file_name = start_dt_str + "_" + end_dt_str + ".log"
    new_file_path = os.path.join(log_path, file_name)

    with open(new_file_path, 'wb') as fh:
        for i in range(date_diff.days + 1):
            cur_dt = start_dt + datetime.timedelta(days=i) 
            fl_iter = _s3_client.get_files(bucket="logs", prefix=cur_dt.strftime("%Y-%m-%d"))

            for fl in fl_iter:
                file_name = fl.key
                m_o = re.match("\d{4}-\d{2}-\d{2}_(\d+)\.[a-zA-Z]+", file_name)
                if m_o: 
                    index = int(m_o.group(1))
                else:
                    continue

                f_o = fl.get()
                body_stream_obj = f_o['Body']
                _sort.add(index, body_stream_obj)

            else:
                sorted_files = _sort.sorted_list()
                if sorted_files:
                    for body_stream_obj in sorted_files:
                        bytes_content = body_stream_obj.read()
                        fh.write(bytes_content)
                    # temp_content = ''.join(map(lambda c: c.read(), sorted_files)) # adding new_line between file parts
                    
                else:
                    logger.info("Some file parts are missing")
                    continue
        else:
            logger.info(f"Merge request completed. File {file_name} created.")

    return new_file_path