class SortConsecutive:

    def __init__(self):
        self._base_arr = [None]
        self._index_count = 0
        self._insertion_count = -1

    def add(self, index, value):
        if index > self._index_count:
            addnl_space = index - self._index_count
            self._base_arr.extend([None] * addnl_space)
            self._index_count = index

        self._base_arr[index] = value
        self._insertion_count += 1
        
    def sorted_list(self):
        if self._insertion_count == self._index_count:
            return self._base_arr