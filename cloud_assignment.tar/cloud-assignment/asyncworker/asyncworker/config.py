# AWS Config Keys
AWS_SERVER_URL='http://minio:9000'
AWS_SERVER_PUBLIC_KEY='minio'
AWS_SERVER_SECRET_KEY='minio123'

# Directory for Merged log files
LOG_PATH='/var/log/merged_logs'