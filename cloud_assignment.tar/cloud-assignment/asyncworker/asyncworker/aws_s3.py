import boto3
from simple_settings import settings
from abc import ABC, abstractmethod

class IAWS(ABC):

    @abstractmethod
    def connect(self, **kwargs):
        pass

    @abstractmethod
    def get_bucket(self, bucket_name):
        pass

    @abstractmethod
    def get_files(self, bucket, prefix=None):
        pass

class S3(IAWS):

    def connect(self, **connection_string):
        self._s3_client = boto3.client('s3')
        pass

    def get_files(self, bucket, prefix=None):
        s3_bucket = self._s3_client.Bucket(bucket)
        return s3_bucket.filter(prefix=f"{prefix}*")