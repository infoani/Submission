import boto3
import asyncworker.config as settings
from abc import ABC, abstractmethod

class IAWS(ABC):

    def __init__(self):
        pass

    @abstractmethod
    def get_files(self, bucket, prefix=None):
        pass

class S3(IAWS):

    def __init__(self):
        self._s3 = boto3.resource('s3',
                    endpoint_url=settings.AWS_SERVER_URL,
                    aws_access_key_id=settings.AWS_SERVER_PUBLIC_KEY,
                    aws_secret_access_key=settings.AWS_SERVER_SECRET_KEY)

    def get_files(self, bucket, prefix=None):
        s3_bucket = self._s3.Bucket(bucket)
        return s3_bucket.objects.filter(prefix=f"{prefix}")

# option to extend to other AWS service like EC2 etc.