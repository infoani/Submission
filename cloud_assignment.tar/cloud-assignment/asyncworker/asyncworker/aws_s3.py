import boto3
from abc import ABC, abstractmethod

class IAWS(ABC):

    @abstractmethod
    def connect(self, **kwargs):
        pass

    @abstractmethod
    def get_files(self, prefix=None):
        pass

class S3(IAWS):

    def connect(self, **connection_string):
        s3 = boto3.client('s3')
        pass

    def get_files(self, prefix=None):
        pass