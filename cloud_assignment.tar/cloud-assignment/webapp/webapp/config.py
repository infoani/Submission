# Directory for Merged log files
LOG_PATH='/var/log/merged_log'