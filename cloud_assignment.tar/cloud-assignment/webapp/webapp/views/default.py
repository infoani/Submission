import os
import json
import logging
import datetime
import redis
import config
import pyramid.httpexceptions as exc
from asyncworker.tasks import merge_s3_files
from pyramid.view import view_config
from pyramid.response import FileResponse, Response

log_path = config.LOG_PATH
logger = logging.getLogger(__name__)


@view_config(route_name="initiate", renderer="json", request_method="POST")
def initiate(request):
    """This function is called when a POST request is made to /initiate.

    According to the assignment the expected POST input is:
    {
        "start_date": "<date in ISO8601 format>",
        "end_date": "<date in ISO8601 format>"
    }
    For example:
    {
        "start_date": "2019-08-18",
        "end_date": "2019-08-25"
    }

    The function should initiate the merging of files on S3 with names between
    the given dates. The actual merging should be offloaded to the async
    executor service.

    The return data is a download ID that the /download endpoint digests:
    {
        "download_id": "<id>"
    }
    For example:
    {
        "download_id": "b0952099-3536-4ea0-a613-98509f4087cd"
    }
    """
    if not (request.POST.get('start_date') and request.POST.get('end_date')):
        errorMessage = "start_date and end_date key must be present in the request body"
        return generate_response(exc.HTTPBadRequest, errorMessage)


    try:
        start_date = datetime.datetime(request.POST['start_date'], "%Y-%m-%d")
        end_date = datetime.datetime(request.POST['end_date'], "%Y-%m-%d")
    except ValueError as err:
        return generate_response(exc.HTTPBadRequest, str(err))

    task_result = merge_s3_files.delay(start_date, end_date)

    return generate_response(exc.HTTPSuccessful, json.dumps({
        "download_id" : task_result.id
        })
    )


@view_config(route_name="download", renderer="json")
def download(request):
    """This function is called when a GET request is made to /download.

    According to the assignment this endpoint accepts the dowload ID as a URL
    parameter and returns the merged file for download if the merging is done.
    If the merging is not done yet, the appropriate HTTP code is returned, so
    the calling client can continue polling.
    """
    logger.info("Download called")

    rds = redis.Redis(host="redisservice")
    download_id = request.matchdict['id']

    redis_id = "celery-task-meta-" + download_id 
    value = rds.get(redis_id)
    if value:
        decoded_value = value.decode('ascii')
        result_value = json.loads(decoded_value)['result']
    else:
        pass

    file_path = os.path.join(log_path, result_value)
    if request.storage.exists(file_path):                                                     #there is no overwrite
        response = FileResponse(file_path)
        response.headers['Content-Disposition'] = (f"attachment; filename={result_value}")
        return response
    else:
        return Response("Unable to find: {}".format(request.path_info))

def generate_response(Type, message):
    response = Type()
    response.body = json.dumps({
        "errorMessage" : message
    })
    response.content_type = 'application/json'

    return response
